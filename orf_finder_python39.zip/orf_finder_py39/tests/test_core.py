import pytest
from orf_finder.core import *


def test_clean_fasta_and_reverse_complement():
    assert clean_sequence(">x\natg ccctaa\n") == "ATGCCCTAA"
    assert reverse_complement("ATGCN") == "NGCAT"


def test_forward_orf_coordinates_translation():
    seq = "CCCATGAAACCCTAAACC"
    hits = find_orfs(seq, min_nt=9, strands="+", start_codons={"ATG"})
    assert len(hits) == 1
    o = hits[0]
    assert (o.start, o.end, o.frame) == (4, 15, 1)
    assert o.protein_sequence == "MKP"
    assert o.length_aa == 3


def test_reverse_orf_coordinates():
    forward = "GGG" + reverse_complement("ATGAAATAA") + "CCC"
    hits = find_orfs(forward, min_nt=9, strands="-", start_codons={"ATG"})
    assert len(hits) == 1
    o = hits[0]
    assert (o.start, o.end, o.biological_start, o.biological_end) == (4, 12, 12, 4)
    assert o.frame < 0


def test_nested_modes():
    seq = "ATGAAAATGCCCTAA"
    all_hits = find_orfs(seq, min_nt=9, strands="+", start_codons={"ATG"}, nested_mode="all")
    longest = find_orfs(seq, min_nt=9, strands="+", start_codons={"ATG"}, nested_mode="longest")
    assert len(all_hits) == 2
    assert len(longest) == 1
    assert any(o.nested for o in all_hits)


def test_frame_filter_and_length_filter():
    seq = "AATGAAATAA"
    assert len(find_orfs(seq, min_nt=9, strands="+", frames={2}, start_codons={"ATG"})) == 1
    assert len(find_orfs(seq, min_nt=12, strands="+", start_codons={"ATG"})) == 0


def test_exports_and_statistics():
    hits = find_orfs("ATGAAATAA", min_nt=9, strands="+")
    assert summary(hits, 9)["orf_count"] == 1
    assert sum(x["count"] for x in codon_usage(hits)) == 1
    assert amino_acid_composition(hits)
    assert intergenic_lengths(hits, 9) == []


def test_invalid_input():
    with pytest.raises(ValueError): clean_sequence("ATGB")
    with pytest.raises(ValueError): find_orfs("ATGTAA", min_nt=100, max_nt=50)
