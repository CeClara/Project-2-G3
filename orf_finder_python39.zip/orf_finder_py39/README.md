# Bacterial ORF Finder - Python 3.9 Compatibility Edition

A complete six-frame bacterial ORF finder with a command-line interface and Dash web app.

## Features

- Plain-text and FASTA input
- All six reading frames and both DNA strands
- Selectable ATG, GTG and TTG starts; TAA, TAG and TGA stops
- Minimum/maximum length, strand and frame filters
- All nested starts or longest candidate per stop
- Correct reverse-strand genomic coordinates
- Translation using bacterial genetic code 11
- Transparent length/start/RBS/overlap confidence heuristic
- Genome map, ORF lengths, codon usage, amino-acid composition and intergenic lengths
- CSV, DNA FASTA, protein FASTA and JSON exports
- Automated unit tests

## Install

Python 3.9.6 or later is supported by this compatibility edition.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Run the web app

```bash
python app.py
```

Open the local address printed in the terminal, normally `http://127.0.0.1:8050`.

## Run from the command line

```bash
python -m orf_finder.cli genome.txt --min-nt 90 --strand both --output-prefix ecoli_orfs
```

Examples:

```bash
# Forward frame 1 only, ATG starts only
python -m orf_finder.cli genome.txt --min-nt 150 --strand + --frames 1 --starts ATG

# Return the longest start-to-stop candidate for each stop codon
python -m orf_finder.cli genome.txt --nested longest
```

## Test

```bash
pytest -q
```

## Output interpretation

Coordinates are 1-based and inclusive. `start` and `end` are always the lower and higher genomic coordinates. For reverse ORFs, `biological_start` is therefore greater than `biological_end`. Frames -1, -2 and -3 are reverse-complement frames.

The confidence score is a project heuristic based on length, start codon, an upstream Shine-Dalgarno-like motif, short length, and nesting. It is useful for ranking candidates but does not prove that a candidate is a real gene. The raw table retains low-confidence candidates so the analysis remains auditable.

## Suggested report evaluation

1. Test synthetic sequences with known forward, reverse and nested ORFs.
2. Compare a subset of translated sequences with another translation/ORF tool.
3. Run the supplied E. coli genome and compare high-confidence predictions to its reference annotation.
4. Report precision, recall and F1 score after defining coordinate-overlap and start-site matching rules.
5. Discuss false positives from cryptic ORFs and false negatives from short genes or non-standard starts.

## Limitations

- Designed for bacterial-style uninterrupted coding regions; it does not splice eukaryotic introns.
- Does not detect incomplete ORFs lacking a start or stop at sequence boundaries.
- RBS scoring is deliberately simple.
- Overlapping true bacterial genes are possible, so overlap is only a weak penalty.
- Specialist tools should be used for production-grade genome annotation.


## Python 3.9 note

This edition has been rewritten to avoid Python 3.10-only union type syntax. Create the virtual environment with your existing Python 3.9.6:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pytest -q
python app.py
```
