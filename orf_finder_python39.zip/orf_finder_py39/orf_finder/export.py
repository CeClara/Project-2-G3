"""Export helpers."""
from __future__ import annotations
import csv
import io
from typing import List
from .core import ORF


def orfs_to_csv(orfs: List[ORF]) -> str:
    output = io.StringIO()
    rows = [o.to_dict() for o in orfs]
    if not rows:
        return ""
    writer = csv.DictWriter(output, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def orfs_to_fasta(orfs: List[ORF], protein: bool = False) -> str:
    chunks = []
    for o in orfs:
        header = (f">{o.id} strand={o.strand} frame={o.frame} "
                  f"coordinates={o.start}-{o.end} score={o.score}")
        seq = o.protein_sequence if protein else o.nucleotide_sequence
        wrapped = "\n".join(seq[i:i+70] for i in range(0, len(seq), 70))
        chunks.append(header + "\n" + wrapped)
    return "\n".join(chunks) + ("\n" if chunks else "")
