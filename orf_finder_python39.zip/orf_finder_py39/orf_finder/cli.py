"""Command-line interface for the ORF finder."""
from __future__ import annotations
import argparse
from pathlib import Path
from .core import clean_sequence, find_orfs, summary, codon_usage, amino_acid_composition
from .export import orfs_to_csv, orfs_to_fasta


def build_parser():
    p = argparse.ArgumentParser(description="Find and analyse bacterial ORFs in six frames.")
    p.add_argument("input", help="Plain-text or FASTA DNA file")
    p.add_argument("--min-nt", type=int, default=90)
    p.add_argument("--max-nt", type=int)
    p.add_argument("--strand", choices=["both", "+", "-"], default="both")
    p.add_argument("--frames", nargs="*", type=int, choices=[-3,-2,-1,1,2,3])
    p.add_argument("--starts", nargs="+", default=["ATG", "GTG", "TTG"])
    p.add_argument("--nested", choices=["all", "longest"], default="all")
    p.add_argument("--output-prefix", default="orf_results")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    seq = clean_sequence(Path(args.input).read_text(encoding="utf-8"))
    orfs = find_orfs(seq, args.min_nt, args.max_nt, args.strand,
                     set(args.frames) if args.frames else None,
                     set(c.upper() for c in args.starts), args.nested)
    prefix = Path(args.output_prefix)
    Path(str(prefix) + ".csv").write_text(orfs_to_csv(orfs), encoding="utf-8")
    Path(str(prefix) + "_dna.fasta").write_text(orfs_to_fasta(orfs), encoding="utf-8")
    Path(str(prefix) + "_protein.fasta").write_text(orfs_to_fasta(orfs, True), encoding="utf-8")
    import json
    stats = {"summary": summary(orfs, len(seq)), "codon_usage": codon_usage(orfs),
             "amino_acid_composition": amino_acid_composition(orfs)}
    Path(str(prefix) + "_statistics.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps(stats["summary"], indent=2))
    print(f"Wrote {len(orfs)} ORFs to {prefix}.csv and FASTA/statistics files.")

if __name__ == "__main__":
    main()
