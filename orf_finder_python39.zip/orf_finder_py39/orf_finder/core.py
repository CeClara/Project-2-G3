"""Core six-frame bacterial ORF detection and analysis."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import Counter
from math import log2
import re
from typing import Dict, List, Optional, Set, Tuple

START_CODONS = {"ATG", "GTG", "TTG"}
STOP_CODONS = {"TAA", "TAG", "TGA"}

# NCBI bacterial/archaeal/plastid code (translation table 11).
CODON_TABLE = {
    'TTT':'F','TTC':'F','TTA':'L','TTG':'L','TCT':'S','TCC':'S','TCA':'S','TCG':'S',
    'TAT':'Y','TAC':'Y','TAA':'*','TAG':'*','TGT':'C','TGC':'C','TGA':'*','TGG':'W',
    'CTT':'L','CTC':'L','CTA':'L','CTG':'L','CCT':'P','CCC':'P','CCA':'P','CCG':'P',
    'CAT':'H','CAC':'H','CAA':'Q','CAG':'Q','CGT':'R','CGC':'R','CGA':'R','CGG':'R',
    'ATT':'I','ATC':'I','ATA':'I','ATG':'M','ACT':'T','ACC':'T','ACA':'T','ACG':'T',
    'AAT':'N','AAC':'N','AAA':'K','AAG':'K','AGT':'S','AGC':'S','AGA':'R','AGG':'R',
    'GTT':'V','GTC':'V','GTA':'V','GTG':'V','GCT':'A','GCC':'A','GCA':'A','GCG':'A',
    'GAT':'D','GAC':'D','GAA':'E','GAG':'E','GGT':'G','GGC':'G','GGA':'G','GGG':'G'
}

@dataclass
class ORF:
    id: str
    strand: str
    frame: int
    start: int              # 1-based inclusive, lower genomic coordinate
    end: int                # 1-based inclusive, higher genomic coordinate
    biological_start: int   # start codon coordinate on the reported strand
    biological_end: int     # final base of stop codon on the reported strand
    length_nt: int
    length_aa: int
    start_codon: str
    stop_codon: str
    nucleotide_sequence: str
    protein_sequence: str
    nested: bool = False
    overlap_count: int = 0
    rbs_motif: str = ""
    rbs_distance: Optional[int] = None
    score: float = 0.0
    confidence: str = ""

    def to_dict(self, include_sequences: bool = True) -> dict:
        d = asdict(self)
        if not include_sequences:
            d.pop("nucleotide_sequence")
            d.pop("protein_sequence")
        return d


def clean_sequence(text: str) -> str:
    """Read raw text or FASTA content and return validated uppercase DNA."""
    if not text or not text.strip():
        raise ValueError("The input sequence is empty.")
    lines = [line.strip() for line in text.splitlines() if not line.startswith(">")]
    seq = re.sub(r"\s+", "", "".join(lines)).upper().replace("U", "T")
    invalid = sorted(set(seq) - set("ACGTN"))
    if invalid:
        raise ValueError("Invalid DNA characters: " + ", ".join(invalid))
    if len(seq) < 3:
        raise ValueError("The sequence must contain at least three nucleotides.")
    return seq


def reverse_complement(sequence: str) -> str:
    return sequence.translate(str.maketrans("ACGTN", "TGCAN"))[::-1]


def translate(sequence: str, force_start_methionine: bool = True) -> str:
    protein = "".join(CODON_TABLE.get(sequence[i:i+3], "X")
                      for i in range(0, len(sequence) - 2, 3))
    if force_start_methionine and protein:
        protein = "M" + protein[1:]
    return protein[:-1] if protein.endswith("*") else protein


def _rbs_evidence(upstream: str) -> Tuple[str, Optional[int], float]:
    """Find a simple Shine-Dalgarno-like motif in the 4-20 nt upstream region."""
    motifs = [("AGGAGG", 1.0), ("GGAGG", .9), ("AGGAG", .85),
              ("GAGG", .7), ("AGGA", .65), ("GGAG", .6)]
    best = ("", None, 0.0)
    for motif, strength in motifs:
        for m in re.finditer(f"(?={motif})", upstream):
            distance = len(upstream) - (m.start() + len(motif))
            if 4 <= distance <= 14:
                spacing = max(0.0, 1.0 - abs(distance - 7) / 10)
                candidate = (motif, distance, strength * spacing)
                if candidate[2] > best[2]:
                    best = candidate
    return best


def _scan_strand(oriented: str, strand: str, genome_length: int,
                 min_nt: int, max_nt: Optional[int], starts: Set[str],
                 nested_mode: str) -> List[ORF]:
    found: List[ORF] = []
    for offset in range(3):
        active_starts: List[int] = []
        for pos in range(offset, len(oriented) - 2, 3):
            codon = oriented[pos:pos+3]
            if codon in starts:
                active_starts.append(pos)
            if codon in STOP_CODONS:
                choices = active_starts[:]
                if nested_mode == "longest" and choices:
                    choices = choices[:1]
                for s in choices:
                    e = pos + 3
                    length = e - s
                    if length < min_nt or (max_nt is not None and length > max_nt):
                        continue
                    nuc = oriented[s:e]
                    upstream = oriented[max(0, s-20):s]
                    motif, distance, _ = _rbs_evidence(upstream)
                    if strand == "+":
                        lo, hi = s + 1, e
                        bio_start, bio_end = lo, hi
                        frame = offset + 1
                    else:
                        lo, hi = genome_length - e + 1, genome_length - s
                        bio_start, bio_end = hi, lo
                        frame = -(offset + 1)
                    found.append(ORF(
                        id="", strand=strand, frame=frame, start=lo, end=hi,
                        biological_start=bio_start, biological_end=bio_end,
                        length_nt=length, length_aa=(length // 3) - 1,
                        start_codon=nuc[:3], stop_codon=nuc[-3:],
                        nucleotide_sequence=nuc,
                        protein_sequence=translate(nuc),
                        rbs_motif=motif, rbs_distance=distance
                    ))
                active_starts = []
    return found


def _mark_relationships(orfs: List[ORF]) -> None:
    for i, a in enumerate(orfs):
        overlaps = 0
        for j, b in enumerate(orfs):
            if i == j:
                continue
            if max(a.start, b.start) <= min(a.end, b.end):
                overlaps += 1
            if (b.start <= a.start and a.end <= b.end and
                    b.length_nt > a.length_nt):
                a.nested = True
        a.overlap_count = overlaps


def _score(orfs: List[ORF]) -> None:
    start_weight = {"ATG": 1.0, "GTG": .72, "TTG": .55}
    for o in orfs:
        length_component = min(1.0, log2(max(o.length_aa, 20) / 20) / 4)
        rbs_component = 0.0
        if o.rbs_motif:
            rbs_component = {"AGGAGG": 1.0, "GGAGG": .9, "AGGAG": .85,
                             "GAGG": .7, "AGGA": .65, "GGAG": .6}[o.rbs_motif]
            rbs_component *= max(.2, 1 - abs((o.rbs_distance or 7) - 7) / 10)
        overlap_penalty = .12 if o.nested else 0
        short_penalty = .16 if o.length_aa < 50 else 0
        o.score = round(max(0, min(1, .55 * length_component +
                                   .20 * start_weight.get(o.start_codon, 0) +
                                   .25 * rbs_component - overlap_penalty - short_penalty)), 3)
        o.confidence = "high" if o.score >= .70 else "medium" if o.score >= .45 else "low"


def find_orfs(sequence: str, min_nt: int = 90, max_nt: Optional[int] = None,
              strands: str = "both", frames: Set[int] | None = None,
              start_codons: Set[str] | None = None,
              nested_mode: str = "all") -> List[ORF]:
    """Find complete start-to-stop ORFs. Coordinates are 1-based inclusive."""
    seq = clean_sequence(sequence)
    if min_nt < 6:
        raise ValueError("Minimum length must be at least 6 nt.")
    if max_nt is not None and max_nt < min_nt:
        raise ValueError("Maximum length must be greater than or equal to minimum length.")
    if nested_mode not in {"all", "longest"}:
        raise ValueError("nested_mode must be 'all' or 'longest'.")
    starts = set(START_CODONS if start_codons is None else start_codons)
    if not starts:
        raise ValueError("Select at least one start codon.")
    invalid_starts = starts - set(CODON_TABLE)
    if invalid_starts:
        raise ValueError("Invalid start codon selection.")
    results: List[ORF] = []
    if strands in {"both", "+"}:
        results += _scan_strand(seq, "+", len(seq), min_nt, max_nt, starts, nested_mode)
    if strands in {"both", "-"}:
        results += _scan_strand(reverse_complement(seq), "-", len(seq), min_nt,
                                max_nt, starts, nested_mode)
    if frames:
        results = [o for o in results if o.frame in frames]
    results.sort(key=lambda o: (o.start, o.end, o.strand))
    _mark_relationships(results)
    _score(results)
    for i, o in enumerate(results, 1):
        o.id = f"ORF_{i:05d}"
    return results


def summary(orfs: List[ORF], genome_length: int) -> dict:
    lengths = [o.length_nt for o in orfs]
    return {
        "genome_length": genome_length,
        "orf_count": len(orfs),
        "forward_count": sum(o.strand == "+" for o in orfs),
        "reverse_count": sum(o.strand == "-" for o in orfs),
        "high_confidence": sum(o.confidence == "high" for o in orfs),
        "mean_length_nt": round(sum(lengths) / len(lengths), 1) if lengths else 0,
        "longest_nt": max(lengths, default=0),
    }


def codon_usage(orfs: List[ORF]) -> List[Dict]:
    counts = Counter()
    for o in orfs:
        # Exclude initiation and termination codons from coding usage.
        counts.update(o.nucleotide_sequence[i:i+3]
                      for i in range(3, len(o.nucleotide_sequence)-3, 3))
    total = sum(counts.values())
    return [{"codon": c, "amino_acid": CODON_TABLE[c], "count": counts[c],
             "frequency_per_1000": round(counts[c] * 1000 / total, 2) if total else 0}
            for c in sorted(CODON_TABLE) if c not in STOP_CODONS]


def amino_acid_composition(orfs: List[ORF]) -> List[Dict]:
    counts = Counter("".join(o.protein_sequence for o in orfs))
    total = sum(counts.values())
    return [{"amino_acid": aa, "count": counts[aa],
             "percentage": round(100 * counts[aa] / total, 2) if total else 0}
            for aa in sorted(counts)]


def intergenic_lengths(orfs: List[ORF], genome_length: int) -> List[int]:
    """Distances between merged ORF-covered intervals; overlapping ORFs give no gap."""
    if not orfs:
        return [genome_length]
    intervals = sorted((o.start, o.end) for o in orfs)
    merged = [list(intervals[0])]
    for start, end in intervals[1:]:
        if start <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return [merged[i+1][0] - merged[i][1] - 1 for i in range(len(merged)-1)]


def flanking_regions(sequence: str, orf: ORF, upstream: int = 50,
                     downstream: int = 50) -> Tuple[str, str]:
    seq = clean_sequence(sequence)
    if orf.strand == "+":
        up = seq[max(0, orf.start-1-upstream):orf.start-1]
        down = seq[orf.end:min(len(seq), orf.end+downstream)]
    else:
        # Extract genomic flanks, then orient them in the direction of transcription.
        up_genomic = seq[orf.end:min(len(seq), orf.end+upstream)]
        down_genomic = seq[max(0, orf.start-1-downstream):orf.start-1]
        up, down = reverse_complement(up_genomic), reverse_complement(down_genomic)
    return up, down
